@echo off
set "URL=https://01a1d8b5-4b28-769b-82a9-3714a8e7f4f0.arena.site/"
start "Cerevia AI" "%URL%"
exit
