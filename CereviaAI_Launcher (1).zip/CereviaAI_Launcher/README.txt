Cerevia AI website launcher

Launch_CereviaAI.bat: Double-click to open the hosted website in your default browser.
CereviaAI.hta: Windows HTA launcher; double-click to redirect to the hosted website.

Important:
This package is a launcher, not an offline copy of the website. Internet access is required.
A true offline app or standalone Windows .EXE requires the website source code/assets and a build process.
